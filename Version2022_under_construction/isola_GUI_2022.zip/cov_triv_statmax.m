function hinv = cov_triv_statmax(nsampl,datafiles,filew)
% This function makes a simple calculation of the Data Covariance Matrix Cd;  
% Covariances will be maximal amplitudes squared
% final output will be the inverted matrix of covariance, Cd-1
% Input
% datafiles is a matrix with station names 
%  code expects the *fil.dat file etc...
% ORDER of the stations MATTERS!! (must be same as in allstat.dat)
% nsampl=number of samples e.g. 1024
% filew=1 or 0 write or not write the hinv.dat  file
%
% Output
% the inverted Cd matrix is returned as output !!
%
% Example
% datafiles={'ANX','PVO','DRO','GUR'}; (raw files must be in same folder)
% cov_triv_statmax(1024,datafiles,1);
% or directly: 
% cov_triv_statmax(1024,{'ANX','PVO','DRO','GUR'},1)
%
% June 2022
%
%
%
%%  
nsampl3=3*nsampl; % 3 components
speye=sparse(eye(nsampl3));
hinv=[];

 %return

%% load datafiles
for ii=1:length(datafiles)
   file=[datafiles{ii} 'fil.dat'];               %%%%%%%%%%%%% fil not raw
   st=load(file);
   maxst=max(max(st(:,2:4)))    % max of all 3 components 
   hinv1=speye/maxst^2;
   hinv=blkdiag(hinv,hinv1); % accumulate matrix per station ; JAK POTLACIT VYPIS na obrazovku ?????????
%  whos
   clear hinv1 st maxst;
end

  


figure 
%spy(hinv);
imagesc(hinv) %plot matrix

disp('filew')
disp(filew)
pause


%% output  %% Printing  Cd-1 into a file (in sparse mode)
if filew == 1
  disp('Be patient ! Printing Cd-1')
  pause
  fid=fopen('hinv.dat','w');
  [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
  %[i,j,s]; % this screen print is OK but i,j have exp. format
  for k=1:size(i)  % this print in loop has correct format
    fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1))
  end
% type hinv.dat % this would print on screen

 fclose(fid);
 disp('hinv.dat created = Cd-1')
 disp('All done !')
else
    disp('output in file was not requested!')
end
 

