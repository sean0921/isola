function C = mustak22(datavar,sigmamult,b,Perwave1,Perwave2,PerCor1,PerCor2,offdiag,filew,nsampl,dt,chol,pert)
%This function makes calculation of Covariance matrix
% based on Mustac and Tkalcic eq.12
% input is datavar, sigmamult , b,Perwave1,Perwave2,PerCor1,PerCor2,offdiag,filew,nsampl,dt
%
% datavar = data variance one value for all !!!
%
% sigmamult must be an array e.g. multiplier values per component !!
% e.g.[1 2 3; 1 2 3; 1 2 3;1 2 3]  4 statios (rows) , 3 components
% (columns) NS, EW, Z
%
% b parameter from paper e.g where b denotes the amplitude of the first cosine function
%
% Perwave1,Perwave2,PerCor1,PerCor2 these are related to re1 and re2 and L1
% and L2  parameters of the paper
% e.g.   Re1=Perwave1/dt   Re2=Perwave2/dt  L1=PerCor1/dt L2=PerCor2/dt
%
% According to Mustak "The periods of the two cosine functions are denoted by L1 and L2 and re1 and re2 are
% their exponential decay factors."
%
% offdiag=1 if we need off diagonal terms, offdiag=0 for diagonal terms only
%
% filew=1 -write file, filew=0 don't write 
% 
% nsampl=1024   i.e.number of samples
%
% chol=1 compute Cholesky decomposition and plot standardized data , 0 not 
%
% pert=1 compute pertubated signal , 0 not 
%
% BE CAREFUL for last two options we need data and now it is fixed to  GURfil.dat
%
%
%  Example 
%
%  mustak22(1.2e-6,[1 1 1;1 1 1;3 3 3;1 1 1],.5,5,10,5,10,0,0,1024,0.24,0,0)
%
%% Start calculation
  [nstations,~] = size(sigmamult);   % number of rows defines the number of stations
  disp(['Calculating for ' num2str(nstations) ' stations'])
  disp('   ' )  
  
%% 
if offdiag==1
%    hinv=[];
% 
%   % load datafiles
%   for ii=1:nstations    % station loop
% 
%    % file=[datafiles{ii} 'raw.dat'];   st=load(file);
%    % nsampl = length(st(:,2));  clear st
%    % compute size of array and pre-allocate
%    % NS comp
%    NS=zeros(nsampl);
%    sigma=datavar*sigmamult(ii,1);
%    
%    for i=1:nsampl % loop for rows
%          for j=1:nsampl % loop for columns
%              
%              NS(i,j) = sigma*(b*exp(-abs(i-j)/decay1)*cos(2*pi*(i-j)/EL1)+(1-b)*exp(-abs(i-j)/decay2)*cos(2*pi*(i-j)/EL2)); 
%          end
%    end
%    
%    % compute size of array and pre-allocate
%    % EW comp
%    EW=zeros(nsampl);
%    sigma=datavar*sigmamult(ii,2);
%    
%    for i=1:nsampl % loop for rows
%          for j=1:nsampl % loop for columns
%              EW(i,j) = sigma*(b*exp(-abs(i-j)/decay1)*cos(2*pi*(i-j)/EL1)+(1-b)*exp(-abs(i-j)/decay2)*cos(2*pi*(i-j)/EL2)); 
%          end
%    end
%    % compute size of array and pre-allocate
%    % Z comp
%    Z=zeros(nsampl);
%    sigma=datavar*sigmamult(ii,3);
%    
%    for i=1:nsampl % loop for rows
%          for j=1:nsampl % loop for columns
%              Z(i,j) = sigma*(b*exp(-abs(i-j)/decay1)*cos(2*pi*(i-j)/EL1)+(1-b)*exp(-abs(i-j)/decay2)*cos(2*pi*(i-j)/EL2)); 
%          end
%    end
%    % combine the 3 comp in one   
%    stamat=[NS EW Z;NS EW Z;NS EW Z];  % station matrix with all 3 components
%    %whos newC
%    speye=sparse(stamat);
%    hinv=blkdiag(hinv,speye);  % add station matrix to Ce for all stations 
%   end  % next station
% 
%   
%    % find inverse matrix of hinv
%    % try to stabilize the inversion
%    [m,n]=size(hinv);
%    figure
%    imagesc(hinv)
%    tt=eye(m,n)/100000;
%    hinv=inv(hinv+tt);
% 
% disp(['Final matrix is of size ' num2str(size(hinv))])
%    

disp('Not enabled yet')

   
else  % offdiag=0
      disp('Off diagonal terms not needed')
      disp('   ' )  

      hinv=[];
      
%% 
Re1=Perwave1/dt; Re2=Perwave2/dt;

L1=PerCor1/dt; L2=PerCor2/dt;
      
%% prepare the "main" matrix once !!
Main=zeros(nsampl);  %preallocate

      for i=1:nsampl % loop for rows
         for j=1:nsampl % loop for columns
           % prepare main matrix of differences  
               Main(i,j)=abs(i-j);  % 
         end
      end

%%      
 for ii=1:nstations    % station loop

      % do this for 3 components
      dvar=datavar*sigmamult(ii,1);  % 
         NCe=dvar*(b*exp(-Main./Re1).*cos(2*pi*Main./L1) ...
            +(1-b)*exp(-Main./Re2).*cos(2*pi*Main./L2));
        
      dvar=datavar*sigmamult(ii,2);  % 
         ECe=dvar*(b*exp(-Main./Re1).*cos(2*pi*Main./L1) ...
            +(1-b)*exp(-Main./Re2).*cos(2*pi*Main./L2));
        
      dvar=datavar*sigmamult(ii,3);  % 
         ZCe=dvar*(b*exp(-Main./Re1).*cos(2*pi*Main./L1) ...
            +(1-b)*exp(-Main./Re2).*cos(2*pi*Main./L2));

        
      sN=sparse(NCe);sE=sparse(ECe);sZ=sparse(ZCe);% make component sparse matrix
      stamat=blkdiag(sN,sE,sZ);   % make station block matrix
      
     % whos stamat NCe ECe ZCe      % figure
     % imagesc(stamat)
     
      hinv=blkdiag(hinv,stamat);  % add this station to all 
      disp(['Finished with station no ' num2str(ii)])
     
 end  % end station
  
   % find inverse matrix of hinv
   % try to stabilize the inversion
%    [m,n]=size(hinv);

     totalCe=hinv;
     
     figure
     imagesc(totalCe)
     colorbar
%    tt=eye(m,n)/100000;

     % invert the matrix 
     hinv=inv(totalCe);
     figure
     imagesc(hinv)
     colorbar

%% compute    Cholecky decomposition
%  spy(hinv)
%  T=cholcov(full(hinv)); %je nutne ??????
if chol==1
   T=cholcov(hinv);
   % get some data
   GUR=load('GURfil.dat');
   NS_GUR=GUR(:,2); time_GUR=GUR(:,1);
   % make NS_GUR row vector use '
   DATA = repmat(NS_GUR',1,nstations*3);
   % whos DATA totalCe

   T2 = T * DATA';  
% plot
   figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
   plot(T2') 
   title('standardized data (5stanic)')
   hold
   plot(DATA*1000,'r')
else
   disp('Not plotting standardized data') 
end
  
%%   
if pert==1
 %  pertub signal
  GUR=load('GURfil.dat');
  NS_GUR=GUR(:,2); time_GUR=GUR(:,1);
  
 % make NS_GUR row vector use '
  DATA = repmat(NS_GUR',1,nstations*3);
 
  % whos DATA totalCe
 
  npert = 100;
  R=mvnrnd(DATA,totalCe,npert);
% 
% whos R
% size(R)
% figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
% plot(R')
% title('Perturbed signal')

%  plot all "pertubed" seismograms one after the other in one plot
plot(R')

else
     disp('Not plotting "pertubed"  data') 
end
     
end
     disp(['Final matrix is of size ' num2str(size(hinv))])  
     disp('   ' )  
     disp(['Final matrix has  ' num2str(numel(hinv))])  
     disp('   ' )  
     disp(['Non zero elements of this matrix are ' num2str(length(find(hinv)))])  
     disp('   ' )  

%% output
if filew == 1

  % Printing  Cd-1 into a file (in sparse mode)
  disp('Be patient ! Printing Cd-1')
  fid=fopen('hinv.dat','w');
   [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
    %[i,j,s]; % this screen print is OK but i,j have exp. format
    for k=1:size(i)  % this print in loop has correct format
      fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1));
    end
    % type hinv.dat % this would print on screen
    disp ('hinv.dat created = Cd-1')
  fclose(fid);
disp ('All done !')

else
    disp ('output in file is not needed !')
end

