%% load data
clear variables

%%
ANX=load('ANXfil.dat'); NS_ANX=ANX(:,2); EW_ANX=ANX(:,3);Z_ANX=ANX(:,4);time_ANX=ANX(:,1);
PVO=load('PVOfil.dat'); NS_PVO=PVO(:,2); EW_PVO=PVO(:,3);Z_PVO=PVO(:,4);time_PVO=PVO(:,1);
DRO=load('DROfil.dat'); NS_DRO=DRO(:,2); EW_DRO=DRO(:,3);Z_DRO=DRO(:,4);time_DRO=DRO(:,1);
GUR=load('GURfil.dat'); NS_GUR=GUR(:,2); EW_GUR=GUR(:,3);Z_GUR=GUR(:,4);time_GUR=GUR(:,1);

%% call axcf
ANX_L1=2; % depends on station distance and model sigma
PVO_L1=2;
DRO_L1=2;
GUR_L1=2;

%T=30;

dt=time_GUR(2)-time_GUR(1)
%
CeANX_NS=axcf(NS_ANX,ANX_L1,dt); 
min(min(CeANX_NS))
max(max(CeANX_NS))
%[max_num, max_ind] = max(CeANX_NS(:))

%pause

CeANX_EW=axcf(EW_ANX,ANX_L1,dt); CeANX_Z =axcf(Z_ANX ,ANX_L1,dt);
CePVO_NS=axcf(NS_PVO,PVO_L1,dt); CePVO_EW=axcf(EW_PVO,PVO_L1,dt); CePVO_Z =axcf(Z_PVO ,PVO_L1,dt);
CeDRO_NS=axcf(NS_DRO,DRO_L1,dt); CeDRO_EW=axcf(EW_DRO,DRO_L1,dt); CeDRO_Z =axcf(Z_DRO ,DRO_L1,dt);
CeGUR_NS=axcf(NS_GUR,GUR_L1,dt); CeGUR_EW=axcf(EW_GUR,GUR_L1,dt); CeGUR_Z =axcf(Z_GUR ,GUR_L1,dt);


% plot 
%figure
%imagesc(blkdiag(CeANX_NS,CePVO_NS)) % plot matrix


%% prepare diagonal matrix of all stations
h_noninv=blkdiag(CeANX_NS,CeANX_EW,CeANX_Z,CePVO_NS,CePVO_EW,CePVO_Z,CeDRO_NS,CeDRO_EW,CeDRO_Z,CeGUR_NS,CeGUR_EW,CeGUR_Z);

%%
uph_noinv=triu(h_noninv);  newh_noninv=uph_noinv+uph_noinv';

npert = 100;
R=mvnrnd(NS_ANX,CeANX_NS,npert);
figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
plot(R')
title('Perturbed signal')

%% add small number in diagonal
[a,b]=size(h_noninv);
tmpmat=eye(a,b).*1.e-9; % EDIT THIS !!!!!!!!!!!!!!!!!good value of small number is near to order of cova ???

before_inv=newh_noninv+tmpmat;
%min(min(before_inv))
%max(max(before_inv))

newinv=inv(before_inv);
%min(min(newinv))
%max(max(newinv))

hinv=newinv;

% whos



[T,num]=cholcov(hinv);
DATA = [NS_ANX' EW_ANX' Z_ANX'   NS_PVO' EW_PVO' Z_PVO'  NS_DRO' EW_DRO'  Z_DRO'   NS_GUR'  EW_GUR'  Z_GUR'   ];
T2 = T * DATA';  
% whos



fig(2)=figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
plot(T2') 
title('standardized data (4 stations)')
hold
plot(DATA*10000,'r')

%DATA = [NS_ANX']






disp('Press any key to save hinv file')

pause

%% Output
    disp(['Final matrix is of size ' num2str(size(hinv))])  
     disp('   ' )  
     disp(['Final matrix has  ' num2str(numel(hinv))])  
     disp('   ' )  
     disp(['Non zero elements of this matrix are ' num2str(length(find(hinv)))])  
     disp('   ' )  

%% output
  % Printing  Cd-1 into a file (in sparse mode)
  disp('Be patient ! Printing Cd-1')
  fid=fopen('hinv.dat','w');
   [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
    %[i,j,s]; % this screen print is OK but i,j have exp. format
    for k=1:size(i)  % this print in loop has correct format
      fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1));
    end
    % type hinv.dat % this would print on screen
    disp ('hinv.dat created = Cd-1')
  fclose(fid);
disp ('All done !')
