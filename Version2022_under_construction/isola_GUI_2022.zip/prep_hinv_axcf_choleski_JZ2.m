clear variables
%close all
%clear all

%% load data
% WARNING: Order of stations here must be that of allstat.dat !!!!!!!!!
disp ('Warning: order the stations as in allstat.dat!! ')

ANX=load('ANXfil.dat'); NS_ANX=ANX(:,2); EW_ANX=ANX(:,3);Z_ANX=ANX(:,4);time_ANX=ANX(:,1);
PVO=load('PVOfil.dat'); NS_PVO=PVO(:,2); EW_PVO=PVO(:,3);Z_PVO=PVO(:,4);time_PVO=PVO(:,1);
DRO=load('DROfil.dat'); NS_DRO=DRO(:,2); EW_DRO=DRO(:,3);Z_DRO=DRO(:,4);time_DRO=DRO(:,1);
GUR=load('GURfil.dat'); NS_GUR=GUR(:,2); EW_GUR=GUR(:,3);Z_GUR=GUR(:,4);time_GUR=GUR(:,1);

DATA = [NS_ANX' EW_ANX' Z_ANX'   NS_PVO' EW_PVO' Z_PVO'  NS_DRO' EW_DRO'  Z_DRO'   NS_GUR'  EW_GUR'  Z_GUR'   ];

%% Set data for axcf
ANX_L1=4; % depends on station distance and model sigma
PVO_L1=4;
DRO_L1=4;
GUR_L1=4;

%T=30; dominant signal length (not needed in axcf) 

dt=time_GUR(2)-time_GUR(1)

% cova matrices of individual stations/components
CeANX_NS=axcf(NS_ANX,ANX_L1,dt); CeANX_EW=axcf(EW_ANX,ANX_L1,dt); CeANX_Z =axcf(Z_ANX ,ANX_L1,dt);
CePVO_NS=axcf(NS_PVO,PVO_L1,dt); CePVO_EW=axcf(EW_PVO,PVO_L1,dt); CePVO_Z =axcf(Z_PVO ,PVO_L1,dt);
CeDRO_NS=axcf(NS_DRO,DRO_L1,dt); CeDRO_EW=axcf(EW_DRO,DRO_L1,dt); CeDRO_Z =axcf(Z_DRO ,DRO_L1,dt);
CeGUR_NS=axcf(NS_GUR,GUR_L1,dt); CeGUR_EW=axcf(EW_GUR,GUR_L1,dt); CeGUR_Z =axcf(Z_GUR ,GUR_L1,dt);



%% prepare COVA matrix of all stations
h_noninv=blkdiag(CeANX_NS,CeANX_EW,CeANX_Z,CePVO_NS,CePVO_EW,CePVO_Z,CeDRO_NS,CeDRO_EW,CeDRO_Z,CeGUR_NS,CeGUR_EW,CeGUR_Z);
%h_noninv=blkdiag(CeANX_NS,CeANX_EW,CeANX_Z,CeANX_NS,CeANX_EW,CeANX_Z,CeANX_NS,CeANX_EW,CeANX_Z,CeANX_NS,CeANX_EW,CeANX_Z);

% symetrization of COVA
uph_noinv=triu(h_noninv);
newh_noninv=uph_noinv+uph_noinv';

%temporary !!!!!without symetrization!!!
%newh_noninv=h_noninv;

figure
plot(newh_noninv(:,1))
%axis equal;
%view(2)
%set(gca,'ydir','reverse') % otoci y osu aby zacinala nahore
%colorbar
title('column 1 of cova without water-level, before inversion ')



disp('ANX_NS')
max(max(CeANX_NS))
disp('PVO_NS')
max(max(CePVO_NS))
disp('DRO_NS')
max(max(CeDRO_NS))
disp('GUR_NS')
max(max(CeGUR_NS))




disp('before inversion, before water level ')
 min( min ( abs(newh_noninv) ) )
 max( max ( abs(newh_noninv) ) )

% min(newh_noninv(:,1)) % -1.09e-16
% max(newh_noninv(:,1)) % +0.86e-16
% min(min(newh_noninv)) % -2.2e-8
% max(max(newh_noninv)) % +5.8e-8
%[S,L] = bounds(newh_noninv,'all');
%min(S)
%max(L)


% plot 
%figure
%imagesc(newh_noninv) % plot matrix 

%perturbation of all stations by COVA without water level
npert = 100;
% R=mvnrnd(NS_ANX,CeANX_NS,npert);
R=mvnrnd(DATA,newh_noninv,npert);      % ??? DATA or DATA' ? Doesn't matter; right? Also below    
figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
plot(R')
title('Perturbed signal without water level')

%pause
%% COVA  with water-level correction (add small numbers on diagonal)
[a,b]=size(newh_noninv);
tmpmat=eye(a,b).*4.0e-12; % EDIT THIS !!good value after J.V. should be (0.02*MAX_stat/comp_DATA)**2
before_inv=newh_noninv+tmpmat;

% COVA water-corrected before inversion
disp('before inversion ')
min(min(before_inv))
max(max(before_inv))

figure
plot(before_inv(:,1))
%axis equal;
%view(2)
%set(gca,'ydir','reverse') % otoci y osu aby zacinala nahore
%colorbar
title('column 1 of cova after water level before inversion ')

disp('size before_inv')
d=size (before_inv)

%perturbation of all stations by COVA with water level
npert = 100;
R=mvnrnd(DATA,before_inv,npert);
figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
plot(R')
title('Perturbed signal with water level')

% INVERSION of COVA (after water correction)
newinv=inv(before_inv);


% COVA water-corrected after inversion
disp('after inversion ')
min(min(newinv))
max(max(newinv))

figure
plot(newinv(:,1))
%axis equal;
%view(2)
%set(gca,'ydir','reverse') % otoci y osu aby zacinala nahore
%colorbar
title('column 1 of the inverted cova')


% final result (inverted COVA with water level)
hinv=newinv;
% whos

% Standardized data (application of Choleski)
[T,num]=cholcov(hinv);
% DATA = [NS_ANX' EW_ANX' Z_ANX'   NS_PVO' EW_PVO' Z_PVO'  NS_DRO' EW_DRO'  Z_DRO'   NS_GUR'  EW_GUR'  Z_GUR'   ];
T2 = T * DATA';  
% whos

% Plot standardized data (application of Choleski) and original data
fig(2)=figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
plot(T2') 
title('standardized data (all stations)')
hold
plot(DATA*10000,'r')

%DATA = [NS_ANX']


disp('Press any key to save hinv file')

pause

%% Output
    disp(['Final matrix is of size ' num2str(size(hinv))])  
     disp('   ' )  
     disp(['Final matrix has  ' num2str(numel(hinv))])  
     disp('   ' )  
     disp(['Non zero elements of this matrix are ' num2str(length(find(hinv)))])  
     disp('   ' )  

%% output
  % Printing  Cd-1 into a file (in sparse mode)
  disp('Be patient ! Printing Cd-1')
  fid=fopen('hinv.dat','w');
   [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
    %[i,j,s]; % this screen print is OK but i,j have exp. format
    for k=1:size(i)  % this print in loop has correct format
      fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1));
    end
    % type hinv.dat % this would print on screen
    disp ('hinv.dat created = Cd-1')
  fclose(fid);
disp ('All done !')
