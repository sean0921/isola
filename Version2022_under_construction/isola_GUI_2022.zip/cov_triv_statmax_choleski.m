function hinv = cov_triv_statmax_choleski(nsampl,datafiles,filew)
% This function makes a simple calculation of the Data Covariance Matrix Cd;  final output will be the inverted matrix of covariance, Cd-1
% Input
% datafiles is a matrix with station names 
% e.g. datafiles={'DSF','EFP','GUR'};  this defines the number of stations
% code expects the DSFraw.dat file etc...
%  
% nsampl=number of samples e.g. 1024
%
% filew=1 or 0 write or not write the hinv.dat  file
%
% Output
% the inverted Cd matrix is returned as output !!
%
% Example
% datafiles={'ANX','PVO','DRO','GUR'}; (raw files must be in same folder)
% cov_triv(1024,datafiles,1);
% or directly: 
% cov_triv(1024,{'ANX','PVO','DRO','GUR'},1)
%
% June 2022
%
%
%
%%  
nsampl3=nsampl; % 3 components
speye=sparse(eye(nsampl3));
hinv=[];

 %return

%% load datafiles
for ii=1:length(datafiles)
   file=[datafiles{ii} 'fil.dat'];               %%%%%%%%%%%%% fil not raw
   st=load(file);
   maxst=max(max(st(:,2:4)))    % max of all 3 components 
  %  maxst^2; % value of Cd for station (anal. of vardat)
%    if ii==2
%        hinv1=speye/100*(maxst^2);   %%%%% BE CAREFUL
%    else
%        hinv1=speye/maxst^2; % station other than 2   ; we DIVIDE by vardat because we calculate INVERSE of Cd  
%    end
   hinv1=speye/maxst^2;
   hinv=blkdiag(hinv,hinv1); % accumulate matrix per station ; JAK POTLACIT VYPIS na obrazovku ?????????
  whos
   clear hinv1 st maxst;
end


  

%%
%figure % no. 3: Cd-1  (sparse) after threshold
spy(hinv);
imagesc(hinv);


%disp('filew')
%disp(filew)



%% output  %% Printing  Cd-1 into a file (in sparse mode)
if filew == 1
  disp('Be patient ! Printing Cd-1')
   
  fid=fopen('hinv.dat','w');
  [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
  %[i,j,s]; % this screen print is OK but i,j have exp. format
  for k=1:size(i)  % this print in loop has correct format
    fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1))
  end
% type hinv.dat % this would print on screen

  fclose(fid);
  disp ('hinv.dat created = Cd-1')
  disp ('All done !')
else
    disp ('output in file is not needed !')
end
 

[T,num]=cholcov(hinv);

ANX=load('ANXfil.dat'); NS_ANX=ANX(:,2); time_ANX=ANX(:,1);
PVO=load('PVOfil.dat'); NS_PVO=PVO(:,2); time_PVO=PVO(:,1);
DRO=load('DROfil.dat'); NS_DRO=DRO(:,2); time_DRO=DRO(:,1);
GUR=load('GURfil.dat'); NS_GUR=GUR(:,2); time_GUR=GUR(:,1);

DATA = [NS_ANX'   NS_PVO'   NS_DRO'   NS_GUR'   ];
T2 = T * DATA';  
whos



fig(2)=figure('units','normalized','color',[1 1 1],'OuterPosition',[0.1,0.1,0.8,0.8]);
plot(T2') 
title('standardized data (1 stanic)')
hold
plot(DATA*1000,'r')

DATA = [NS_ANX']



