function C = mustak11(datavar,sigmamult,decay,offdiag,filew,nsampl)
%This function makes calculation of Covariance matrix
% based on Mustac and Tkalcic eq.11 
% input is sigma, decay, and data files as station names only (raw)
%
% prescribe decay as
% decay = (1/fmax)/dt   fmax maximum inverted frequency
%
% datavar = data variance one value for all !!! will be changed according
% to sigmamult
%
% sigmamult must be an array e.g. multiplier values per component !!
% e.g.[1 2 3; 1 2 3; 1 2 3;1 2 3]  4 statios (rows) , 3 components
% (columns) NS, EW, Z
%
% offdiag=1 if we need off diagonal terms, offdiag=0 for diagonal terms only
%
% filew=1 -write file, filew=0 don't write 
% 
% nsampl=1024   i.e.number of samples
%
%  e.g.
%
%   mustak1(1.2e-6,[1 1 1; 1 1 1; 3 3 3;1 1 1],40,0,0,1024);
%
%% Start calculation
 
  [nstations,~] = size(sigmamult);   % number of rows defines the number of stations
  
  disp(['Calculating for ' num2str(nstations) ' stations'])
  
%% 
if offdiag==1
   hinv=[];

  % load datafiles
  for ii=1:nstations    % station loop

   % file=[datafiles{ii} 'raw.dat'];   st=load(file);
   % nsampl = length(st(:,2));  clear st
   % compute size of array and pre-allocate
   % NS comp
   NS=zeros(nsampl);
   
   for i=1:nsampl % loop for rows
         for j=1:nsampl % loop for columns
             NS(i,j) = datavar*sigmamult(ii,1)*exp(-abs(i-j)/decay) ;
         end
   end
   % compute size of array and pre-allocate
   % EW comp
   EW=zeros(nsampl);
   for i=1:nsampl % loop for rows
         for j=1:nsampl % loop for columns
             EW(i,j) = datavar*sigmamult(ii,2)*exp(-abs(i-j)/decay) ;
         end
   end
   % compute size of array and pre-allocate
   % Z comp
   Z=zeros(nsampl);
   for i=1:nsampl % loop for rows
         for j=1:nsampl % loop for columns
             Z(i,j) = datavar*sigmamult(ii,3)*exp(-abs(i-j)/decay) ;
         end
   end
   % combine the 3 comp in one   
   stamat=[NS EW Z;NS EW Z;NS EW Z];  % station matrix with all 3 components
   %whos newC
   speye=sparse(stamat);
   hinv=blkdiag(hinv,speye);  % add station matrix to Ce for all stations 
  end  % next station

  
   % find inverse matrix of hinv
   % try to stabilize the inversion
   [m,n]=size(hinv);
   figure
   imagesc(hinv)
   tt=eye(m,n)/100000;
   hinv=inv(hinv+tt);

disp(['Final matrix is of size ' num2str(size(hinv))])
   
   
else  % offdiag=0
    
       disp('Off diagonal terms not needed')
       hinv=[];

%% 
Main=zeros(nsampl);  %preallocate

      for i=1:nsampl % loop for rows
         for j=1:nsampl % loop for columns
           % prepare main matrix of differences  
               Main(i,j)=abs(i-j);  % 
         end
      end

%%      
 for ii=1:nstations    % station loop
     
    NCe=datavar*sigmamult(ii,1)*exp(-Main./decay);
    ECe=datavar*sigmamult(ii,2)*exp(-Main./decay);
    ZCe=datavar*sigmamult(ii,3)*exp(-Main./decay);
     
    sN=sparse(NCe);sE=sparse(ECe);sZ=sparse(ZCe);% make component sparse matrix
    stamat=blkdiag(sN,sE,sZ);   % make station block matrix
    hinv=blkdiag(hinv,stamat);  % add this station to all 
    disp(['Finished with station no ' num2str(ii)])     
     
%    %file=[datafiles{ii} 'raw.dat'];   st=load(file);
%    %nsampl = length(st(:,2));   clear st
%    % compute size of array and pre-allocate
%    % for all 3 comp
%    allcomp=zeros(nsampl*3);
%    
%    for i=1:nsampl*3 % loop for rows
%          for j=1:nsampl*3 % loop for columns
%              allcomp(i,j) = datavar*sigmamult(ii,1)*exp(-abs(i-j)/decay) ;
%          end
%    end    
% 
%    speye=sparse(allcomp);
%    hinv=blkdiag(hinv,speye);  % add station matrix to Ce for all stations    
    
 end  % end station
  
   % find inverse matrix of hinv
   % try to stabilize the inversion
%    [m,n]=size(hinv);
     disp('Computing inverse')
     figure
     imagesc(hinv)
%    tt=eye(m,n)/100000;
     hinv=inv(hinv);
      
     disp(['Final matrix is of size ' num2str(size(hinv))])  
  
end
  
%% output
if filew == 1

  % Printing  Cd-1 into a file (in sparse mode)
  disp('Be patient ! Printing Cd-1')
 fid=fopen('hinv.dat','w');
  [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
  %[i,j,s]; % this screen print is OK but i,j have exp. format
  for k=1:size(i)  % this print in loop has correct format
    fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1));
  end
  % type hinv.dat % this would print on screen
  disp ('hinv.dat created = Cd-1')
 fclose(fid);
disp ('All done !')

else
    disp ('output in file is not needed !')
end

%%
figure; imagesc(hinv)

%%
% figure
% surf(C)
% axis equal;
% view(2)
% set(gca,'ydir','reverse') % otoci y osu aby zacinala nahore
% colorbar
% title('Cova matrix')
  % break
